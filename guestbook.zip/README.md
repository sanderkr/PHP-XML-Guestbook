Simple PHP/XML Guestbook without database
=======
Just load on FTP and you're done.

Live demo here: <a href="http://jedenbod.cz/gb">http://jedenbod.cz/gb</a>